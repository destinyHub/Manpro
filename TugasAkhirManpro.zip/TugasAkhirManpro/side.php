<div class="sideNav">
    <ul>
        <li id="menu"><p>MENU</p></li>
        <hr>
        <li><a href="../user/book.php" class="side">Book List</a></li>
        <hr>
        <li><a href="../user/borrow.php" class="side">Borrowing History</a></li>
        <hr>
        <li><a href="../general/journals.php" class="side">Download Journals</a></li>
        <hr>
    </ul>
</div>