<div class="sideNav">
    <ul>
        <li id="menu"><p>MENU</p></li>
        <hr>
        <li><a href="../admin/books.php" class="side">Book List</a></li>
        <hr>
        <li><a href="../admin/member.php" class="side">Member List</a></li>
        <hr>
        <li><a href="../admin/admList.php" class="side">Administrator List</a></li>
        <hr>
        <li><a href="../general/journals.php" class="side">Download Journals</a></li>
        <hr>
    </ul>
</div>